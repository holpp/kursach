﻿using System;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace course_work
{
    public partial class Form1 : Form
    {
        private MySqlConnection connection;
        private string server;
        private string database;
        private string uid;
        private string password;
        private string connectionString;
        private DataTable originalDataTable;
        private MySqlCommand command;
        private MySqlDataAdapter adapter;
        private DataTable dataTable;
        public Form1()
        {
            InitializeComponent();
            InitializeConnection();
            LoadMovies();
            dataGridView2.CellClick += dataGridView2_CellClick;
            this.textBox1.TextChanged += new System.EventHandler(this.textBoxSearch_TextChanged);
            btnAddMovie.Click += new EventHandler(btnAddMovie_Click);
            dataGridView2.AutoGenerateColumns = true;
            dataGridView2.Columns["Актёры"].Width = 300;
            dataGridView2.Columns["Жанры"].Width = 200;
        }
        private void InitializeConnection()
        {
            server = "localhost";
            database = "course_work";
            uid = "root";
            password = "";
            connectionString = "SERVER=" + server + ";" + "DATABASE=" +
            database + ";" + "UID=" + uid + ";" + "PASSWORD=" + password + ";CHARSET=utf8;";

            connection = new MySqlConnection(connectionString);
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            LoadMovies();
        }
        private void OpenConnection()
        {
            if (connection.State == ConnectionState.Closed)
            {
                connection.Open();
            }
        }

        private void CloseConnection()
        {
            if (connection.State == ConnectionState.Open)
            {
                connection.Close();
            }
        }

        private void LoadMovies()
        {
            try
            {
                OpenConnection();
                string query = @"
                SELECT 
                    m.mName AS 'Название',
                    m.mCont AS 'Длительность',
                    m.mDescription AS 'Описание',
                    cd.dFullName AS 'Режиссёры',
                    GROUP_CONCAT(DISTINCT cac.acFullname SEPARATOR ', ') AS 'Актёры',
                    GROUP_CONCAT(DISTINCT cg.gName SEPARATOR ', ') AS 'Жанры'
                FROM c_movies m
                LEFT JOIN m_d_list ON m_d_list.IDm = m.IDm
                  LEFT JOIN c_directors cd ON cd.IDd = m_d_list.IDd
                LEFT JOIN m_ac_list ON m_ac_list.IDm = m.IDm
                  LEFT JOIN c_actors cac ON cac.IDac = m_ac_list.IDac
                LEFT JOIN m_g_list ON m_g_list.IDm = m.IDm
                  LEFT JOIN c_genres cg ON cg.IDg = m_g_list.IDg
                GROUP BY m.mName, m.mCont, m.mDescription, cd.dFullName";
                adapter = new MySqlDataAdapter(query, connection); // Выбираем все столбцы из таблицы
                originalDataTable = new DataTable(); // Инициализируем исходные данные
                adapter.Fill(originalDataTable);

                // Отображаем исходные данные в DataGridView
                dataGridView2.DataSource = originalDataTable;

                dataGridView2.Columns["Название"].HeaderText = "Название";
                dataGridView2.Columns["Длительность"].HeaderText = "Длительность";
                dataGridView2.Columns["Режиссёры"].HeaderText = "Режиссёр";
                dataGridView2.Columns["Актёры"].HeaderText = "Актёры";
                dataGridView2.Columns["Жанры"].HeaderText = "Жанры";
                dataGridView2.Columns["Описание"].Visible = false;


                CloseConnection();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при загрузке фильмов: " + ex.Message);
            }
        }


        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                string title = dataGridView2.Rows[e.RowIndex].Cells["Название"].Value.ToString();
                string description = dataGridView2.Rows[e.RowIndex].Cells["Описание"].Value.ToString();

                MessageBox.Show($"Название: {title}\n\nОписание: {description}");
            }
        }

        private void textBoxSearch_TextChanged(object sender, EventArgs e)
        {
            string searchText = textBox1.Text.Trim();

            try
            {
                OpenConnection();

                string query;
                if (searchText == "")
                {
                    // Если строка поиска пустая, используем исходные данные
                    dataTable = originalDataTable.Copy(); // Копируем исходные данные
                }
                else
                {
                    // Если строка поиска не пустая, выполняем запрос с поиском
                    query = @"SELECT 
                        m.mName AS 'Название',
                        m.mCont AS 'Длительность',
                        m.mDescription AS 'Описание',
                        cd.dFullName AS 'Режиссёры',
                        GROUP_CONCAT(DISTINCT cac.acFullname SEPARATOR ', ') AS 'Актеры',
                        GROUP_CONCAT(DISTINCT cg.gName SEPARATOR ', ') AS 'Жанры'
                    FROM c_movies m
                    LEFT JOIN m_d_list ON m_d_list.IDm = m.IDm
                      LEFT JOIN c_directors cd ON cd.IDd = m_d_list.IDd
                    LEFT JOIN m_ac_list ON m_ac_list.IDm = m.IDm
                      LEFT JOIN c_actors cac ON cac.IDac = m_ac_list.IDac
                    LEFT JOIN m_g_list ON m_g_list.IDm = m.IDm
                      LEFT JOIN c_genres cg ON cg.IDg = m_g_list.IDg
                    WHERE mName LIKE @searchText
                    GROUP BY m.mName, m.mCont, m.mDescription, cd.dFullName";
                    adapter = new MySqlDataAdapter(query, connection);
                    adapter.SelectCommand.Parameters.AddWithValue("@searchText", "%" + searchText + "%");

                    dataTable = new DataTable(); // Создаем новую таблицу для результатов запроса
                    adapter.Fill(dataTable); // Заполняем таблицу результатами запроса
                }

                // Отображаем результаты запроса в DataGridView
                dataGridView2.DataSource = dataTable;

                CloseConnection();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при загрузке фильмов: " + ex.Message);
            }
        }

        private void btnAddMovie_Click(object sender, EventArgs e)
        {
            Form2 secondForm = new Form2(); // Создание экземпляра второй формы
            secondForm.Show(); // Отображение второй формы
        }
    }
}