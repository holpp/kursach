﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace course_work
{
    public partial class Form2 : Form
    {
        private MySqlConnection connection;
        private string server;
        private string database;
        private string uid;
        private string password;
        private string connectionString;
        public Form2()
        {
            InitializeComponent();
            InitializeConnection();
            btnConfirm.Click += new EventHandler(btnConfirm_Click);
            btnCancel.Click += new EventHandler(btnCancel_Click);
            LoadActors();
            LoadDirectors();
            LoadGenres();
        }

        private void InitializeConnection()
        {
            server = "localhost";
            database = "course_work";
            uid = "root";
            password = "";
            connectionString = "SERVER=" + server + ";" + "DATABASE=" +
            database + ";" + "UID=" + uid + ";" + "PASSWORD=" + password + ";CHARSET=utf8;";

            connection = new MySqlConnection(connectionString);
        }

        private void OpenConnection()
        {
            if (connection.State == ConnectionState.Closed)
            {
                connection.Open();
            }
        }

        private void CloseConnection()
        {
            if (connection.State == ConnectionState.Open)
            {
                connection.Close();
            }
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            string movieName = textBox1.Text;
            string movieDuration = textBox2.Text;
            string movieDescription = textBox3.Text;

            List<string> selectedActors = new List<string>();
            foreach (int index in ac_CLB.CheckedIndices)
            {
                selectedActors.Add(ac_CLB.Items[index].ToString());
            }

            List<string> selectedDirectors = new List<string>();
            foreach (int index in d_CLB.CheckedIndices)
            {
                selectedDirectors.Add(d_CLB.Items[index].ToString());
            }

            List<string> selectedGenres = new List<string>();
            foreach (int index in g_CLB.CheckedIndices)
            {
                selectedGenres.Add(g_CLB.Items[index].ToString());
            }

            SaveMovie(movieName, movieDuration, movieDescription, selectedActors, selectedDirectors, selectedGenres);
        }

        private void SaveMovie(string name, string duration, string description, List<string> actors, List<string> directors, List<string> genres)
        {
            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                var transaction = conn.BeginTransaction();

                try
                {
                    // Добавление фильма
                    string movieQuery = "INSERT INTO c_movies (mName, mCont, mDescription) VALUES (@name, @duration, @description);";
                    MySqlCommand movieCmd = new MySqlCommand(movieQuery, conn);
                    movieCmd.Parameters.AddWithValue("@name", name);
                    movieCmd.Parameters.AddWithValue("@duration", duration);
                    movieCmd.Parameters.AddWithValue("@description", description);
                    movieCmd.ExecuteNonQuery();
                    long movieId = movieCmd.LastInsertedId;

                    // Добавление связей фильма с актёрами
                    foreach (var actorName in actors)
                    {
                        // Предположим, что в таблице c_actors имена актёров уникальны и используются для связи
                        string actorQuery = "INSERT INTO m_ac_list (IDm, IDac) VALUES (@movieId, (SELECT IDac FROM c_actors WHERE acFullName = @actorName));";
                        MySqlCommand actorCmd = new MySqlCommand(actorQuery, conn);
                        actorCmd.Parameters.AddWithValue("@movieId", movieId);
                        actorCmd.Parameters.AddWithValue("@actorName", actorName);
                        actorCmd.ExecuteNonQuery();
                    }

                    // Аналогично можно добавить для режиссёров и жанров
                    foreach (var directorName in directors)
                    {
                        // Предположим, что в таблице c_actors имена актёров уникальны и используются для связи
                        string directorQuery = "INSERT INTO m_d_list (IDm, IDd) VALUES (@movieId, (SELECT IDd FROM c_directors WHERE dFullName = @directorName));";
                        MySqlCommand directorCmd = new MySqlCommand(directorQuery, conn);
                        directorCmd.Parameters.AddWithValue("@movieId", movieId);
                        directorCmd.Parameters.AddWithValue("@actorName", directorName);
                        directorCmd.ExecuteNonQuery();
                    }

                    foreach (var genreName in genres)
                    {
                        // Предположим, что в таблице c_actors имена актёров уникальны и используются для связи
                        string genreQuery = "INSERT INTO m_g_list (IDm, IDg) VALUES (@movieId, (SELECT IDg FROM c_genres WHERE gName = @genreName));";
                        MySqlCommand genreCmd = new MySqlCommand(genreQuery, conn);
                        genreCmd.Parameters.AddWithValue("@movieId", movieId);
                        genreCmd.Parameters.AddWithValue("@actorName", genreName);
                        genreCmd.ExecuteNonQuery();
                    }
                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при сохранении фильма: " + ex.Message);
                    transaction.Rollback();
                }
                finally
                {
                    if (conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }
                }
            }
        }



        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void LoadActors()
        {
            string connectionString = "SERVER=localhost;DATABASE=course_work;UID=root;PASSWORD=;";
            string query = "SELECT IDac, acFullName FROM c_actors;";

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    MySqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        string actorName = reader["acFullName"].ToString();
                        ac_CLB.Items.Add(actorName);
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при загрузке актёров: " + ex.Message);
                }
            }
        }

        private void LoadDirectors()
        {
            string connectionString = "SERVER=localhost;DATABASE=course_work;UID=root;PASSWORD=;";
            string query = "SELECT IDd, dFullName FROM c_directors;";

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    MySqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        string directorName = reader["dFullName"].ToString();
                        d_CLB.Items.Add(directorName);
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при загрузке актёров: " + ex.Message);
                }
            }
        }

        private void LoadGenres()
        {
            string connectionString = "SERVER=localhost;DATABASE=course_work;UID=root;PASSWORD=;";
            string query = "SELECT IDg, gName FROM c_genres;";

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    MySqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        string genreName = reader["gName"].ToString();
                        g_CLB.Items.Add(genreName);
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при загрузке актёров: " + ex.Message);
                }
            }
        }
    }
}
